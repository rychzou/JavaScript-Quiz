// 1. A start button - clicking it will start a timer and present questions
// 2. Timner - starting from 75
// 3. Questions change upon being answered
// 4. Questions answered incorrectly subtract time
// 5. Game over when time reaches zero
// 6. Game over when all questions are answered.
// 7. User input - save initials and score.
// 8. Button for deleting scoreboard.
// 9. Will show if I got question right or wrong.
// A function with a timer that will count down from 75 seconds.
// A function to display the questions. If user chooses correct answer, 
// Create a start button with an event listener that will invoke the timer and display quiz functions.
var timeLimit = 75;
var timeCountDown;
var timeRemaining = document.getElementById('time-remaining');

var questions = [
    {
        question: "Commonly used data types DO NOT include:",
        choices: ["string", "boolean", "alerts", "numbers"],
        answer: 2
    },
    {
        question: "The condition in an if/else statement is enclosed within: ",
        choices: ["quotes", "curly brackets", "parenthesese", "square brackets"],
        answer: 2
    },
    {
        question: "Arrays in JavaScript can be used to store: ",
        choices: ["numbers and strings", "other arrays", "booleans", "all of the above"],
        answer: 3
    },
    {
        question: "String values must be enclosed within _____ when being assigned to variables.",
        choices: ["commas", "curly brackets", "quotes", "parenthesese"],
        answer: 2
    },
    {
        question: "A very useful tool during development and debugging for printing content to the debugger is:",
        choices: ["JavaScript", "terminal/bash", "for loops", "console.log"],
        answer: 3
    },
]


function displayQuestion() {
    for (var i = 0; i < questions.length; i++) {
        var question = questions[i].question;
        document.write(question);
        var options = questions[i].choices;
        document.write(options);
        checkAnswerChoice;
    }
}

function checkAnswerChoice(userChoice) {
    var userChoice = parseInt()
}


function startQuiz() {
    startTimer;

}

function displayTime() {
    timer.textContent = timeLimit;
}

function startTimer() {
    timeCountDown = setInterval(function () {
        timeLimit--;
        displayTime;

    }, 1000);
}




